import React from 'react';
import { 
  Dumbbell, 
  Clock, 
  Users, 
  Tag, 
  ShoppingBag,
  ChevronLeft, 
  ChevronRight,
  Instagram,
  Facebook,
  Twitter
} from 'lucide-react';

function App() {
  const testimonials = [
    {
      name: "Sarah Johnson",
      text: "FITMAP transformed my fitness journey. The trainers are exceptional!",
      image: "https://images.unsplash.com/photo-1594381898411-846e7d193883?auto=format&fit=crop&q=80&w=200&h=200"
    },
    {
      name: "Mike Chen",
      text: "The scheduling system makes it so easy to stay consistent with my workouts.",
      image: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?auto=format&fit=crop&q=80&w=200&h=200"
    },
    {
      name: "Emma Davis",
      text: "Love the community and the results I've achieved with FITMAP!",
      image: "https://images.unsplash.com/photo-1499952127939-9bbf5af6c51c?auto=format&fit=crop&q=80&w=200&h=200"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <header className="relative h-screen">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&q=80&w=1920')",
          }}
        >
          <div className="absolute inset-0 bg-black bg-opacity-50" />
        </div>
        
        <nav className="relative z-10 container mx-auto px-6 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Dumbbell className="h-8 w-8 text-white" />
              <span className="text-2xl font-bold text-white">FITMAP</span>
            </div>
            <div className="hidden md:flex space-x-8 text-white">
              <a href="#features" className="hover:text-gray-300">Features</a>
              <a href="#captains" className="hover:text-gray-300">Captains</a>
              <a href="#membership" className="hover:text-gray-300">Membership</a>
              <a href="#shop" className="hover:text-gray-300">Shop</a>
            </div>
            <div className="space-x-4">
              <button className="px-4 py-2 text-white hover:text-gray-300">Login</button>
              <button className="px-6 py-2 bg-blue-600 text-white rounded-full hover:bg-blue-700">
                Join Now
              </button>
            </div>
          </div>
        </nav>

        <div className="relative z-10 container mx-auto px-6 h-[calc(100vh-88px)] flex items-center">
          <div className="max-w-2xl">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
              Transform Your Fitness Journey
            </h1>
            <p className="text-xl text-gray-200 mb-8">
              Join the ultimate fitness platform that connects you with expert trainers,
              personalized workouts, and a supportive community.
            </p>
            <div className="space-x-4">
              <button className="px-8 py-3 bg-blue-600 text-white rounded-full hover:bg-blue-700 text-lg">
                Join Now
              </button>
              <button className="px-8 py-3 bg-white text-blue-600 rounded-full hover:bg-gray-100 text-lg">
                Explore Trainings
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Features Section */}
      <section id="features" className="py-20 bg-gray-50">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-16">Why Choose FITMAP?</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { icon: <Clock className="h-8 w-8" />, title: "24/7 Scheduling" },
              { icon: <Users className="h-8 w-8" />, title: "Expert Captains" },
              { icon: <Tag className="h-8 w-8" />, title: "Exclusive Offers" },
              { icon: <ShoppingBag className="h-8 w-8" />, title: "Premium Products" }
            ].map((feature, index) => (
              <div key={index} className="text-center p-6 bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow">
                <div className="inline-block p-3 bg-blue-100 rounded-full text-blue-600 mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">
                  Experience the best in fitness with our comprehensive platform.
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Latest Offers Banner */}
      <section className="bg-blue-600 py-8">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="text-white mb-4 md:mb-0">
              <h3 className="text-2xl font-bold">Special Summer Offer! 🌟</h3>
              <p>Get 20% off on annual memberships + free personal training session</p>
            </div>
            <button className="px-8 py-3 bg-white text-blue-600 rounded-full hover:bg-gray-100">
              Claim Offer
            </button>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-bold text-center mb-16">Success Stories</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name}
                  className="w-20 h-20 rounded-full mx-auto mb-4 object-cover"
                />
                <p className="text-gray-600 text-center mb-4">"{testimonial.text}"</p>
                <p className="font-semibold text-center">{testimonial.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Dumbbell className="h-6 w-6" />
                <span className="text-xl font-bold">FITMAP</span>
              </div>
              <p className="text-gray-400">
                Transform your fitness journey with the ultimate gym platform.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">About Us</a></li>
                <li><a href="#" className="hover:text-white">Membership</a></li>
                <li><a href="#" className="hover:text-white">Shop</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white">Terms of Service</a></li>
                <li><a href="#" className="hover:text-white">Cookie Policy</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Connect With Us</h4>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-white">
                  <Instagram className="h-6 w-6" />
                </a>
                <a href="#" className="text-gray-400 hover:text-white">
                  <Facebook className="h-6 w-6" />
                </a>
                <a href="#" className="text-gray-400 hover:text-white">
                  <Twitter className="h-6 w-6" />
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} FITMAP. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;